package com.safira.FootballApps.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.os.Build.ID
import com.safira.FootballApps.model.FavMatch
import org.jetbrains.anko.db.*

class DatabaseOpen (ctx: Context) : ManagedSQLiteOpenHelper(ctx, "Favorite.db", null, 1) {


    companion object {
        private var instance: DatabaseOpen? = null

        @Synchronized
        fun getInstance(ctx: Context): DatabaseOpen {
            if (instance == null) {
                instance = DatabaseOpen(ctx.applicationContext)
            }
            return instance as DatabaseOpen
        }
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.createTable(FavMatch.TABLE_FAVORITE, true,
            FavMatch.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
            FavMatch.ID_EVENT to TEXT + UNIQUE,
            FavMatch.STR_EVENT to TEXT,
            FavMatch.SCORE_AWAY to TEXT,
            FavMatch.SCORE_HOME to TEXT,
            FavMatch.DATE_EVENT to TEXT,
            FavMatch.ID_HOME_TEAM to TEXT,
            FavMatch.ID_AWAY_TEAM to TEXT)

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.dropTable(FavMatch.TABLE_FAVORITE, true)
    }
}

val Context.database : DatabaseOpen
    get() = DatabaseOpen.getInstance(applicationContext)