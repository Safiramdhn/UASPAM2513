package com.safira.FootballApps.ui.favorites

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.safira.FootballApps.adapter.FavMatchAdapter
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.startActivity

class FavMatchFragment : Fragment() {

    private var favoriteMatchFields: MutableList<FavoriteMatchField> = mutableListOf()
    private lateinit var adapter: FavMatchAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favorite_match, container, false)
    }


    private fun  showFavorite() {
        favoriteMatchFields.clear()
        context?.database?.use {
            val result = select(FavoriteMatchField.TABLE_FAVORITE)
            val favorite = result.parseList(classParser<FavoriteMatchField>())
            favoriteMatchFields.addAll(favorite)
            adapter.notifyDataSetChanged()
        }
    }


}