package com.safira.FootballApps.presenter

import com.google.gson.Gson
import com.safira.FootballApps.API.ApiRepository
import com.safira.FootballApps.model.MatchResponse
import com.safira.FootballApps.ui.match.MatchViewModel
import com.safira.FootballApps.ui.match.PreviousMatchView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class MatchPresenter {
    private val view: PreviousMatchView,
    private val apiRepository: ApiRepository,
    private val gson: Gson
    ) {

        fun getPreviousMatch(idLeague: String?) {
            view.showLoading()
            GlobalScope.launch(Dispatchers.Main) {
                val data = gson.fromJson(apiRepository
                    .doRequest(ApiRepository.TheSportDBApi.getPreviousMatch(idLeague)).await(),
                    MatchResponse::class.java
                )
                view.hideLoading()
                view.showPreviousMatch(data.matchResponse)

            }

        }
    }
}