package com.safira.FootballApps.ui.team

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.safira.FootballApps.R
import androidx.recyclerview.widget.LinearLayoutManager
import com.safira.FootballApps.activity.DetailTeamActivity
import com.safira.FootballApps.model.Teams
import com.safira.FootballApps.ui.team.TeamViewModel
import com.safira.FootballApps.API.ApiRepository
import com.google.gson.Gson
import com.safira.FootballApps.adapter.TeamAdapter
import com.safira.FootballApps.presenter.TeamListPresenter
import kotlinx.android.synthetic.main.fragment_team.*
import com.safira.FootballApps.model.DetailTeam
import org.jetbrains.anko.startActivity




class TeamFragment : Fragment(),ListTeamView{

    private lateinit var teamViewModel: TeamViewModel
    private lateinit var presenter: TeamListPresenter
    private lateinit var adapter: TeamAdapter
    private var items: MutableList<Teams> = mutableListOf()

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_team, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val apiRepository = ApiRepository()
        val gson = Gson()

        presenter = TeamListPresenter(this, apiRepository, gson)

        adapter = TeamAdapter(context, items) {
            context?.startActivity<DetailTeamActivity>(DetailTeamActivity.ARGS_ID to "${it.idTeam}")
        }

        rvTeam.layoutManager = LinearLayoutManager(context)
        rvTeam.adapter = adapter
    }

    override fun showListTeam(data: List<Teams>) {
        items.clear()
        items.addAll(data)
        adapter.notifyDataSetChanged()
    }
}