package com.safira.FootballApps.activity

class DetailTeamActivity {
}