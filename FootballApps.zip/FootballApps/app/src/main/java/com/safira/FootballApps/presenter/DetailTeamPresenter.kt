package com.safira.FootballApps.presenter

import com.google.gson.Gson
import com.safira.FootballApps.API.ApiRepository
import com.safira.FootballApps.model.DetailTeamResponse
import com.safira.FootballApps.ui.team.TeamViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DetailTeamPresenter(
    private val view: TeamViewModel,
    private val apiRepository: ApiRepository,
    private val gson: Gson
) {

    fun getTeamDetail(idTeam: String?) {

        GlobalScope.launch (Dispatchers.Main) {

            val data = gson.fromJson(apiRepository
                .doRequest(ApiRepository.TheSportDBApi.getTeamDetails(idTeam)).await(),
                DetailTeamResponse::class.java)

            view.showTeamDetail(data.detailTeamsResponse)
        }
    }
}