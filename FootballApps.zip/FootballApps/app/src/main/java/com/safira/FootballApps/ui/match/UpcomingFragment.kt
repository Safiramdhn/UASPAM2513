package com.safira.FootballApps.ui.match

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.safira.FootballApps.API.ApiRepository
import com.safira.FootballApps.R
import com.safira.FootballApps.adapter.UpcomingAdapter
import org.jetbrains.anko.startActivity

class UpcomingFragment {

    lateinit var presenter: UpcomingPresenter
    private var match: MutableList<Match> = mutableListOf()
    private lateinit var adapter: UpcomingAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.upcoming_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val apiRepository = ApiRepository()
        val gson = Gson()
        presenter = UpcomingPresenter(this, apiRepository, gson)

        presenter.getUpcomingMatch(DetailLigaActivity.idLeague)

        adapter = UpcomingMatchAdapter(context, match) {
            context?.startActivity<DetailMatchActivity>("id" to "${it.idEvent}",
                DetailMatchActivity.ARGS_ID_AWAY to "${it.idAwayTeam}",
                DetailMatchActivity.ARGS_ID_HOME to "${it.idHomeTeam}")
        }

        rvUpcomingMatch.layoutManager = LinearLayoutManager(context)
        rvUpcomingMatch.adapter = adapter
    }

    override fun showUpcomingMatch(data: List<Match>) {
        match.clear()
        match.addAll(data)
        adapter.notifyDataSetChanged()
    }

}
}