package com.safira.FootballApps.ui.match

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.safira.FootballApps.API.ApiRepository
import com.safira.FootballApps.R
import com.safira.FootballApps.adapter.MatchAdapter
import org.jetbrains.anko.startActivity

class MatchFragment : Fragment() {

    lateinit var presenter: PreviousMatchPresenter
    private var match: MutableList<Match> = mutableListOf()
    private lateinit var adapter: MatchAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.team_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val apiRepository = ApiRepository()
        val gson = Gson()
        presenter = PreviousMatchPresenter(this, apiRepository, gson)
        presenter.getPreviousMatch(DetailLigaActivity.idLeague)

        rvPreviousMatch.layoutManager = LinearLayoutManager(context)
        rvPreviousMatch.adapter = adapter
    }

    override fun showPreviousMatch(data: List<Match>) {
        match.clear()
        match.addAll(data)
        adapter.notifyDataSetChanged()
    }

    override fun showLoading() {
        progressBarPrevious.visible()
    }

    override fun hideLoading() {
        progressBarPrevious.invisible()
    }
}