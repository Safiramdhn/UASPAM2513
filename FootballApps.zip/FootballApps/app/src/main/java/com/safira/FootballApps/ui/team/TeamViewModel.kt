package com.safira.FootballApps.ui.team

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.safira.FootballApps.model.DetailTeam
import com.safira.FootballApps.model.Teams

class TeamViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Team View"
    }
    val text: LiveData<String> = _text
}

interface TeamsView {
    fun showTeams(homeTeams: List<Teams>, awayTeams: List<Teams>)
}

interface DetailTeamView{
    fun showTeamDetail(data: List<DetailTeam>)
}
